export function expectation(passed: boolean) {
  return passed ? 'not to have' : 'to have';
}
