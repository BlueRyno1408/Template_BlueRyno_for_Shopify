import requestNextAnimationFrame from './requestNextAnimationFrame';

export default requestNextAnimationFrame;
