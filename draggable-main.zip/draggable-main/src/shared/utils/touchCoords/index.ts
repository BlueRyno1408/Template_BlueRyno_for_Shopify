import touchCoords from './touchCoords';

export default touchCoords;
