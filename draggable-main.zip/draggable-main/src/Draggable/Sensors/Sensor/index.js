import Sensor from './Sensor';

export default Sensor;
